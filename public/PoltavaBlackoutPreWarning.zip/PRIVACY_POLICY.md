# Privacy Policy / Політика конфіденційності

**Effective Date:** November 9, 2026  
**Last Updated:** November 9, 2026  
**Application Name:** Світло в Полтаві (PoltavaBlackoutPreWarning)  
**Package Name / Application ID:** `ua.blackout.prewarning.poltava`  
**Developer / Publisher:** Igor Zaharov  
**Open-Source Repository:** [https://github.com/IgorZaharov/PoltavaBlackoutPreWarning](https://github.com/IgorZaharov/PoltavaBlackoutPreWarning)  
**Contact / Issue Tracker:** [https://github.com/IgorZaharov/PoltavaBlackoutPreWarning/issues](https://github.com/IgorZaharov/PoltavaBlackoutPreWarning/issues)  

---

## 1. Introduction and Scope

This Privacy Policy governs the mobile application **"Світло в Полтаві"** (package name `ua.blackout.prewarning.poltava`, hereinafter referred to as the "Application", "App", "we", "us", or "our"), created and maintained by Igor Zaharov as a free, open-source community utility.

The Application is designed to provide residents and organizations in the Zhytomyr region of Ukraine with timely, accurate information regarding scheduled electrical power outages (Графіки погодинних відключень електроенергії) published by **JSC "Zhytomyroblenergo" (АТ «Житомиробленерго»)**.

We are strictly committed to user privacy and digital sovereignty. This document outlines our data handling practices in accordance with the **Google Play Developer Program Policies**, the **General Data Protection Regulation (GDPR) (EU) 2016/679**, the **Law of Ukraine "On Protection of Personal Data" (Закон України «Про захист персональних даних» № 2297-VI)**, and applicable privacy standards.

---

## 2. Principle of Zero Data Collection (Data Minimization)

In strict adherence to the principle of data minimization (Article 5(1)(c) of the GDPR):

- **No Personal Data Collected:** The Application does **not** collect, solicit, aggregate, record, store, sell, lease, or monetize any Personally Identifiable Information (PII).
- **No User Accounts:** There is no registration, login, profile creation, or authentication required to use the Application.
- **No Advertising or Behavioral Profiling:** The Application contains no advertising frameworks, ad-tracking SDKs, or commercial behavioral profiling mechanisms. It does not access the Android Advertising ID (AAID).
- **No Analytics or Telemetry:** The Application does not integrate third-party analytics services (e.g., Google Analytics for Firebase, Firebase Crashlytics, AppsFlyer, Mixpanel, or Facebook SDK). We do not collect telemetry, diagnostic crash reports containing device IDs, or usage statistics.
- **No Location Tracking:** The Application does not request or access GPS, coarse location, Wi-Fi SSID information, or cellular tower triangulation data.

---

## 3. Information Processed Locally on the User's Device

All configuration settings and operational data created during application use are retained **strictly on the user's physical device** within the sandboxed Android application private storage (`SharedPreferences` under `Context.MODE_PRIVATE`). This information is never transmitted to any external server or third party.

Locally stored parameters include:

1. **Selected Power Outage Queue:** The user's chosen consumer sub-queue (e.g., queues `1.1` through `6.2`).
2. **Notification & Pre-Warning Settings:** The user's chosen pre-warning lead time (e.g., 15 or 30 minutes in advance), sound toggles, and vibration toggles.
3. **Audio Preferences:** Sound effects and music volume sliders.
4. **Offline Cache:** Cached electricity outage schedule tables to enable offline viewing when network access is unavailable.

---

## 4. Network Connections and Data Sources

The Application requires internet access exclusively to fetch publicly accessible data necessary for its primary utility function:

1. **JSC "Zhytomyroblenergo" Official Schedule Server:**
   - **Target Endpoint:** `https://www.ztoe.com.ua/unhooking-search.php`
   - **Purpose:** Retrieving publicly published hourly power outage schedule HTML tables for the 12 consumer sub-queues.
   - **Data Transmitted:** Standard HTTP/HTTPS GET requests. No user credentials, cookies, device identifiers, or personal parameters are sent with these requests.
2. **Static Configuration File (GitHub Raw):**
   - **Target Endpoint:** `https://raw.githubusercontent.com/IgorZaharov/PoltavaBlackoutPreWarning/main/donations.json`
   - **Purpose:** Periodically retrieving optional community donation URLs and official information links using standard conditional HTTP headers (`ETag` / `If-Modified-Since`).
   - **Data Transmitted:** Anonymous static file GET request. No telemetry or user information is transmitted.

---

## 5. Android Device Permissions and Technical Justification

In full compliance with Google Play Developer Program Policies regarding sensitive permissions, the Application requests only the minimal set of Android system permissions strictly essential for its core utility:

| Permission | Technical Requirement & Justification |
| :--- | :--- |
| `android.permission.INTERNET` | Required to communicate via HTTPS with the public servers of JSC "Zhytomyroblenergo" and retrieve blackout schedules. |
| `android.permission.ACCESS_NETWORK_STATE` | Required to verify whether an active Wi-Fi or cellular network connection is available prior to initiating network queries, preventing unnecessary battery and data consumption. |
| `android.permission.POST_NOTIFICATIONS` | Required on Android 13 (API level 33) and higher to present local notifications warning the user of imminent electrical outages according to their configured preference. |
| `android.permission.SCHEDULE_EXACT_ALARM`<br/>`android.permission.USE_EXACT_ALARM` | Required to schedule exact, time-critical local alarms using Android `AlarmManager`. This ensures that pre-warning notifications trigger at the precise minute chosen by the user (e.g., exactly 15 minutes before an outage) even when the device is in low-power Doze mode. The Application qualifies under Google Play policies for time-critical alert and calendar/reminder utilities. |
| `android.permission.RECEIVE_BOOT_COMPLETED` | Required to automatically restore and reschedule the user's configured local outage warning alarms following a device reboot or system time/timezone adjustment. |
| `android.permission.VIBRATE` | Required to deliver haptic vibration feedback alongside notifications if enabled in the user's notification channel settings. |
| `android.permission.WAKE_LOCK` | Required momentarily during exact alarm broadcasts to guarantee that the notification dispatch routine completes successfully before the device returns to sleep. |

The Application does **not** request access to contacts, cameras, microphones, location, phone state, external shared storage, SMS, or sensitive hardware sensors.

---

## 6. Third-Party Links and External Services

The Application contains hyperlinks to external third-party platforms for the convenience of the user:

- **JSC "Zhytomyroblenergo" (АТ «Житомиробленерго»):** [https://www.ztoe.com.ua](https://www.ztoe.com.ua)
- **Official Zhytomyroblenergo Facebook Page:** For official emergency announcements.
- **Voluntary Community Donations (Monobank / Charity Jar):** Direct links that open in the user's external web browser or banking application. The Application does not process payments, store banking credentials, or receive transaction records.
- **Project GitHub Repository:** [https://github.com/IgorZaharov/PoltavaBlackoutPreWarning](https://github.com/IgorZaharov/PoltavaBlackoutPreWarning)

We do not control, oversee, or assume responsibility for the privacy practices, content, or policies of external websites. When navigating to third-party services, users are advised to review the respective third-party privacy notices.

---

## 7. Children's Privacy (COPPA & GDPR Compliance)

The Application is a public utility intended for general audiences. It does not target, knowingly interact with, or collect information from children under the age of 13 (or under 16 within the European Economic Area). 

Because the Application does not collect, retain, or transmit personal data of any kind, it is fully safe for all age groups and compliant with the **Children's Online Privacy Protection Act (COPPA)** and the **Google Play Families Policy**.

---

## 8. Data Storage, Security, and Retention

- **Storage Location:** All user-specific settings are confined exclusively to the local file system sandbox of the Android operating system on the user's device.
- **Security:** Data is protected by Android's application sandboxing architecture and file system encryption. We do not operate remote databases, cloud synchronization servers, or user data repositories.
- **Data Deletion:** The user retains complete sovereignty over their data. All stored preferences and local caches can be irrevocably deleted at any time by:
  1. Navigating on the device to **Settings > Apps > Світло в Полтаві > Storage > Clear Data**; or
  2. Uninstalling the Application from the device.

---

## 9. User Rights Under GDPR and Ukrainian Law

In accordance with Chapter III of the GDPR (Regulation (EU) 2016/679) and Article 8 of the Law of Ukraine "On Protection of Personal Data" (Закон України «Про захист персональних даних»):

- Users possess rights regarding access, rectification, erasure, and restriction of processing of personal data.
- Because the Application processes **no personal data** on external servers and retains only user-controlled settings on the local device, users directly exercise all rights of access, rectification, and erasure instantly through the application interface or by wiping local app data.

---

## 10. Modifications to this Privacy Policy

We reserve the right to update this Privacy Policy to reflect changes in legal requirements, technical enhancements, or Google Play Store standards. Any modifications will be posted to the official repository with an updated "Last Updated" date. Continued use of the Application after revisions constitutes acknowledgment of the updated terms.

---

## 11. Contact Information

If you have questions, feedback, or legal inquiries concerning this Privacy Policy, please contact the developer through our public issue tracker:

- **Lead Developer:** Igor Zaharov
- **GitHub Issues:** [https://github.com/IgorZaharov/PoltavaBlackoutPreWarning/issues](https://github.com/IgorZaharov/PoltavaBlackoutPreWarning/issues)
- **Project Repository:** [https://github.com/IgorZaharov/PoltavaBlackoutPreWarning](https://github.com/IgorZaharov/PoltavaBlackoutPreWarning)

---

# Політика конфіденційності (Офіційна українська версія)

**Дата набрання чинності:** 9 листопада 2026 року  
**Останнє оновлення:** 9 листопада 2026 року  
**Назва додатку:** Світло в Полтаві (PoltavaBlackoutPreWarning)  
**Ідентифікатор пакета (Package Name):** `ua.blackout.prewarning.poltava`  
**Розробник:** Ігор Захаров (Igor Zaharov)  
**Репозиторій проєкту:** [https://github.com/IgorZaharov/PoltavaBlackoutPreWarning](https://github.com/IgorZaharov/PoltavaBlackoutPreWarning)  

### 1. Загальні положення
Ця Політика конфіденційності регулює використання мобільного додатку **«Світло в Полтаві»** (`ua.blackout.prewarning.poltava`), розробленого як безкоштовний некомерційний інструмент для жителів міста Житомира та Житомирської області для оперативного відстеження графіків погодинних відключень електроенергії (ГПВ) АТ «Житомиробленерго».

### 2. Повна відсутність збору персональних даних
- Додаток **не збирає**, не реєструє, не передає та не продає персональні дані користувачів.
- Реєстрація або вхід в обліковий запис відсутні.
- У додатку відсутні рекламні мережі, рекламні трекери, аналітичні системи (наприклад, Google Analytics, Firebase SDK, Facebook SDK) та збір рекламних ідентифікаторів.
- Додаток не відстежує геопозицію користувача (GPS чи дані мережі).

### 3. Локальні дані на пристрої
Усі налаштування користувача (номер черги від 1.1 до 6.2, час завчасного попередження, рівень звуку, локальні бали мінігри) зберігаються **виключно локально** у захищеному сховищі пристрою (`SharedPreferences`) і ніколи не передаються стороннім особам чи серверам.

### 4. Мережеві запити
Додаток звертається через захищене з'єднання виключно до:
1. Офіційного сайту АТ «Житомиробленерго» (`https://www.ztoe.com.ua/unhooking-search.php`) для завантаження відкритих графіків відключень.
2. Статичного файлу конфігурації у відкритому репозиторії GitHub для оновлення офіційних посилань.
Жодні ідентифікатори пристрою чи користувача під час цих запитів не надсилаються.

### 5. Дозволи Android
- `INTERNET` та `ACCESS_NETWORK_STATE`: для отримання публічного графіка та перевірки наявності з'єднання.
- `POST_NOTIFICATIONS`: для показу локальних сповіщень про початок або завершення відключення.
- `SCHEDULE_EXACT_ALARM` та `USE_EXACT_ALARM`: для гарантованого спрацьовування таймера попередження у точний час.
- `RECEIVE_BOOT_COMPLETED`: для автоматичного відновлення запланованих таймерів після перезавантаження телефону.
- `VIBRATE` та `WAKE_LOCK`: для коректного доставлення сигналу сповіщення.

### 6. Видалення даних
Користувач може в будь-який момент повністю видалити всі локальні налаштування, очистивши дані програми в налаштуваннях Android або видаливши додаток.

### 7. Контакти
З будь-яких питань щодо функціонування додатку або цієї політики можна звернутися через офіційний репозиторій:  
[https://github.com/IgorZaharov/PoltavaBlackoutPreWarning/issues](https://github.com/IgorZaharov/PoltavaBlackoutPreWarning/issues)
